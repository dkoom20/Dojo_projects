using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Auctions.Models;
using System.Linq;
using Microsoft.EntityFrameworkCore;


namespace Auctions.Controllers
{
    public class ProcessController : Controller
    {
        private AuctionsContext _context;

        public ProcessController(AuctionsContext context)
        {
            _context = context;
        }

         public User Logged_user
        {
            get {return _context.users.SingleOrDefault(u => u.id == (int)HttpContext.Session.GetInt32("id"));}
        }


    }
}