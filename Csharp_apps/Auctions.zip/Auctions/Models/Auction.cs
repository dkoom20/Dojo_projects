using System;

namespace Auctions.Models 
{
    public class Auction
    {
        public int id { get; set; }
        public int creator_id { get; set; }
        public string product { get; set; }
        public string description { get; set; }
        public User User { get; set; }
        public int opening_bid { get; set; }
        public DateTime ending_at { get; set; }
        public DateTime created_at { get; set; }


    }
}