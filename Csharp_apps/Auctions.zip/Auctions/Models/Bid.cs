using System;

namespace Auctions.Models 
{
    public class Bid
    {
        public int id { get; set; }
        public int user_id { get; set; }
        public int auction_id { get; set; }
        public int amount { get; set; }
        public DateTime created_at { get; set; }


    }
}